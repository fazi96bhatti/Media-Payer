﻿namespace Media_Player
{
    partial class Player
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Player));
            this.MediaPlayer = new AxWMPLib.AxWindowsMediaPlayer();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_skipback = new System.Windows.Forms.Button();
            this.btn_skipforward = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_volume = new System.Windows.Forms.Label();
            this.volume = new System.Windows.Forms.TrackBar();
            this.btn_exit = new System.Windows.Forms.Button();
            this.btn_stop = new System.Windows.Forms.Button();
            this.tn_next = new System.Windows.Forms.Button();
            this.btn_previous = new System.Windows.Forms.Button();
            this.btn_pause = new System.Windows.Forms.Button();
            this.btn_Play = new System.Windows.Forms.Button();
            this.lbl_starttime = new System.Windows.Forms.Label();
            this.lbl_endtime = new System.Windows.Forms.Label();
            this.list = new System.Windows.Forms.ListBox();
            this.Open = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.progress = new System.Windows.Forms.TrackBar();
            this.lbl_state = new System.Windows.Forms.Label();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.MediaPlayer)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.volume)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.progress)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // MediaPlayer
            // 
            this.MediaPlayer.Dock = System.Windows.Forms.DockStyle.Top;
            this.MediaPlayer.Enabled = true;
            this.MediaPlayer.Location = new System.Drawing.Point(0, 0);
            this.MediaPlayer.Name = "MediaPlayer";
            this.MediaPlayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("MediaPlayer.OcxState")));
            this.MediaPlayer.Size = new System.Drawing.Size(1928, 558);
            this.MediaPlayer.TabIndex = 0;
            this.MediaPlayer.Enter += new System.EventHandler(this.MediaPlayer_Enter);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbl_state);
            this.groupBox1.Controls.Add(this.btn_skipback);
            this.groupBox1.Controls.Add(this.btn_skipforward);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.lbl_volume);
            this.groupBox1.Controls.Add(this.volume);
            this.groupBox1.Controls.Add(this.btn_exit);
            this.groupBox1.Controls.Add(this.btn_stop);
            this.groupBox1.Controls.Add(this.tn_next);
            this.groupBox1.Controls.Add(this.btn_previous);
            this.groupBox1.Controls.Add(this.btn_pause);
            this.groupBox1.Controls.Add(this.btn_Play);
            this.groupBox1.Font = new System.Drawing.Font("MingLiU-ExtB", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.groupBox1.Location = new System.Drawing.Point(0, 916);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1918, 187);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Controls";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // btn_skipback
            // 
            this.btn_skipback.BackColor = System.Drawing.Color.Black;
            this.btn_skipback.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_skipback.Location = new System.Drawing.Point(444, 64);
            this.btn_skipback.Name = "btn_skipback";
            this.btn_skipback.Size = new System.Drawing.Size(150, 59);
            this.btn_skipback.TabIndex = 6;
            this.btn_skipback.Text = "-10";
            this.btn_skipback.UseVisualStyleBackColor = false;
            this.btn_skipback.Click += new System.EventHandler(this.btn_skipback_Click);
            // 
            // btn_skipforward
            // 
            this.btn_skipforward.BackColor = System.Drawing.Color.Black;
            this.btn_skipforward.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_skipforward.Location = new System.Drawing.Point(1031, 64);
            this.btn_skipforward.Name = "btn_skipforward";
            this.btn_skipforward.Size = new System.Drawing.Size(150, 59);
            this.btn_skipforward.TabIndex = 5;
            this.btn_skipforward.Text = "+10";
            this.btn_skipforward.UseVisualStyleBackColor = false;
            this.btn_skipforward.Click += new System.EventHandler(this.btn_skipforward_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(1356, 143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(600, 40);
            this.label1.TabIndex = 4;
            this.label1.Text = "Media Player by Muhammad Faizan";
            // 
            // lbl_volume
            // 
            this.lbl_volume.BackColor = System.Drawing.Color.Black;
            this.lbl_volume.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_volume.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.lbl_volume.Location = new System.Drawing.Point(1753, 64);
            this.lbl_volume.Name = "lbl_volume";
            this.lbl_volume.Size = new System.Drawing.Size(110, 41);
            this.lbl_volume.TabIndex = 3;
            this.lbl_volume.Text = "0%";
            this.lbl_volume.Click += new System.EventHandler(this.lbl_volume_Click);
            // 
            // volume
            // 
            this.volume.AutoSize = false;
            this.volume.Location = new System.Drawing.Point(1611, 62);
            this.volume.Maximum = 100;
            this.volume.Name = "volume";
            this.volume.Size = new System.Drawing.Size(142, 37);
            this.volume.TabIndex = 1;
            this.volume.Scroll += new System.EventHandler(this.volume_Scroll);
            // 
            // btn_exit
            // 
            this.btn_exit.BackColor = System.Drawing.Color.Black;
            this.btn_exit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_exit.Location = new System.Drawing.Point(1398, 64);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(207, 59);
            this.btn_exit.TabIndex = 0;
            this.btn_exit.Text = "Exit";
            this.btn_exit.UseVisualStyleBackColor = false;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // btn_stop
            // 
            this.btn_stop.BackColor = System.Drawing.Color.Black;
            this.btn_stop.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_stop.Location = new System.Drawing.Point(1185, 64);
            this.btn_stop.Name = "btn_stop";
            this.btn_stop.Size = new System.Drawing.Size(207, 59);
            this.btn_stop.TabIndex = 0;
            this.btn_stop.Text = "Stop";
            this.btn_stop.UseVisualStyleBackColor = false;
            this.btn_stop.Click += new System.EventHandler(this.btn_stop_Click);
            // 
            // tn_next
            // 
            this.tn_next.BackColor = System.Drawing.Color.Black;
            this.tn_next.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.tn_next.Location = new System.Drawing.Point(815, 64);
            this.tn_next.Name = "tn_next";
            this.tn_next.Size = new System.Drawing.Size(207, 59);
            this.tn_next.TabIndex = 0;
            this.tn_next.Text = "Next";
            this.tn_next.UseVisualStyleBackColor = false;
            this.tn_next.Click += new System.EventHandler(this.tn_next_Click);
            // 
            // btn_previous
            // 
            this.btn_previous.BackColor = System.Drawing.Color.Black;
            this.btn_previous.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_previous.Location = new System.Drawing.Point(601, 64);
            this.btn_previous.Name = "btn_previous";
            this.btn_previous.Size = new System.Drawing.Size(207, 59);
            this.btn_previous.TabIndex = 0;
            this.btn_previous.Text = "Previous";
            this.btn_previous.UseVisualStyleBackColor = false;
            this.btn_previous.Click += new System.EventHandler(this.btn_previous_Click);
            // 
            // btn_pause
            // 
            this.btn_pause.BackColor = System.Drawing.Color.Black;
            this.btn_pause.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_pause.Location = new System.Drawing.Point(231, 64);
            this.btn_pause.Name = "btn_pause";
            this.btn_pause.Size = new System.Drawing.Size(207, 59);
            this.btn_pause.TabIndex = 0;
            this.btn_pause.Text = "Pause";
            this.btn_pause.UseVisualStyleBackColor = false;
            this.btn_pause.Click += new System.EventHandler(this.btn_pause_Click);
            // 
            // btn_Play
            // 
            this.btn_Play.BackColor = System.Drawing.Color.Black;
            this.btn_Play.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_Play.Location = new System.Drawing.Point(18, 64);
            this.btn_Play.Name = "btn_Play";
            this.btn_Play.Size = new System.Drawing.Size(207, 59);
            this.btn_Play.TabIndex = 0;
            this.btn_Play.Text = "Play";
            this.btn_Play.UseVisualStyleBackColor = false;
            this.btn_Play.Click += new System.EventHandler(this.btn_Play_Click);
            // 
            // lbl_starttime
            // 
            this.lbl_starttime.BackColor = System.Drawing.Color.Black;
            this.lbl_starttime.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_starttime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.lbl_starttime.Location = new System.Drawing.Point(12, 857);
            this.lbl_starttime.Name = "lbl_starttime";
            this.lbl_starttime.Size = new System.Drawing.Size(173, 38);
            this.lbl_starttime.TabIndex = 4;
            this.lbl_starttime.Text = "00:00";
            this.lbl_starttime.Click += new System.EventHandler(this.lbl_starttime_Click);
            // 
            // lbl_endtime
            // 
            this.lbl_endtime.BackColor = System.Drawing.Color.Black;
            this.lbl_endtime.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_endtime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.lbl_endtime.Location = new System.Drawing.Point(1757, 856);
            this.lbl_endtime.Name = "lbl_endtime";
            this.lbl_endtime.Size = new System.Drawing.Size(123, 38);
            this.lbl_endtime.TabIndex = 5;
            this.lbl_endtime.Text = "00:00";
            this.lbl_endtime.Click += new System.EventHandler(this.lbl_endtime_Click);
            // 
            // list
            // 
            this.list.BackColor = System.Drawing.Color.Black;
            this.list.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.list.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.list.ForeColor = System.Drawing.Color.Aqua;
            this.list.FormattingEnabled = true;
            this.list.ItemHeight = 29;
            this.list.Location = new System.Drawing.Point(-2, 1);
            this.list.Name = "list";
            this.list.Size = new System.Drawing.Size(915, 754);
            this.list.TabIndex = 6;
            this.list.UseWaitCursor = true;
            this.list.SelectedIndexChanged += new System.EventHandler(this.list_SelectedIndexChanged);
            // 
            // Open
            // 
            this.Open.BackColor = System.Drawing.Color.Black;
            this.Open.Font = new System.Drawing.Font("MingLiU-ExtB", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Open.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Open.Location = new System.Drawing.Point(1660, 690);
            this.Open.Name = "Open";
            this.Open.Size = new System.Drawing.Size(207, 59);
            this.Open.TabIndex = 4;
            this.Open.Text = "Add_Files";
            this.Open.UseVisualStyleBackColor = false;
            this.Open.Click += new System.EventHandler(this.Open_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // progress
            // 
            this.progress.AutoSize = false;
            this.progress.Location = new System.Drawing.Point(134, 857);
            this.progress.Name = "progress";
            this.progress.Size = new System.Drawing.Size(1617, 37);
            this.progress.TabIndex = 7;
            this.progress.Scroll += new System.EventHandler(this.progress_Scroll);
            // 
            // lbl_state
            // 
            this.lbl_state.AutoSize = true;
            this.lbl_state.BackColor = System.Drawing.Color.Transparent;
            this.lbl_state.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_state.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.lbl_state.Location = new System.Drawing.Point(838, 18);
            this.lbl_state.Name = "lbl_state";
            this.lbl_state.Size = new System.Drawing.Size(146, 32);
            this.lbl_state.TabIndex = 8;
            this.lbl_state.Text = "Stopped...";
            // 
            // Player
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1928, 1106);
            this.ControlBox = false;
            this.Controls.Add(this.list);
            this.Controls.Add(this.progress);
            this.Controls.Add(this.Open);
            this.Controls.Add(this.lbl_endtime);
            this.Controls.Add(this.lbl_starttime);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.MediaPlayer);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Player";
            this.Text = "Media Player By Muhammad Faizan";
            this.Load += new System.EventHandler(this.Player_Load);
            ((System.ComponentModel.ISupportInitialize)(this.MediaPlayer)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.volume)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.progress)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private AxWMPLib.AxWindowsMediaPlayer MediaPlayer;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.Button btn_stop;
        private System.Windows.Forms.Button tn_next;
        private System.Windows.Forms.Button btn_previous;
        private System.Windows.Forms.Button btn_pause;
        private System.Windows.Forms.Button btn_Play;
        private System.Windows.Forms.Label lbl_volume;
        private System.Windows.Forms.TrackBar volume;
        private System.Windows.Forms.Label lbl_starttime;
        private System.Windows.Forms.Label lbl_endtime;
        private System.Windows.Forms.ListBox list;
        private System.Windows.Forms.Button Open;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TrackBar progress;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_skipback;
        private System.Windows.Forms.Button btn_skipforward;
        private System.Windows.Forms.Label lbl_state;
        private System.Windows.Forms.BindingSource bindingSource1;
    }
}