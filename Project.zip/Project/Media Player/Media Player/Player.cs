﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Media_Player
{
    public partial class Player : Form
    {
        string[] file_name, path;


        public Player()
        {
            InitializeComponent();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_stop_Click(object sender, EventArgs e)
        {
            MediaPlayer.Ctlcontrols.stop();
            MediaPlayer.SendToBack();
            MediaPlayer.URL = null;
            timer1.Stop();
            lbl_endtime.Text = "00:00";
            lbl_starttime.Text = "00:00";
            for (int x = 0; x < file_name.Length; x++)
            {
                list.Items.Remove(file_name[x]);
            }
            lbl_state.Text = "Stopped...";

        }

        private void lbl_volume_Click(object sender, EventArgs e)
        {

        }

        private void list_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void MediaPlayer_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btn_Play_Click(object sender, EventArgs e)
        {
            if (MediaPlayer.URL == path[list.SelectedIndex])
            {
                MediaPlayer.Ctlcontrols.play();
                lbl_state.Text = "Playing...";
            }
            else
            {
                MediaPlayer.URL = path[list.SelectedIndex];
                MediaPlayer.BringToFront();
                MediaPlayer.Ctlcontrols.play();
                timer1.Start();
                volume.Value = 25;
                lbl_volume.Text = volume.Value.ToString() + " %";
                lbl_state.Text = "Playing...";
            }
        }

        private void btn_pause_Click(object sender, EventArgs e)
        {
            MediaPlayer.Ctlcontrols.pause();
            lbl_state.Text = "Paused...";
        }

        private void btn_previous_Click(object sender, EventArgs e)
        {
            if (list.SelectedIndex > 0)
            {
                list.SelectedIndex = list.SelectedIndex - 1;
                MediaPlayer.URL = path[list.SelectedIndex];
                MediaPlayer.BringToFront();
                MediaPlayer.Ctlcontrols.play();
                timer1.Start();
                volume.Value = 25;
                lbl_volume.Text = volume.Value.ToString() + " %";
                lbl_state.Text = "Playing...";
            }
            else if (list.SelectedIndex == 0)
            {
                list.SelectedIndex = list.Items.Count - 1;
                MediaPlayer.URL = path[list.SelectedIndex];
                MediaPlayer.BringToFront();
                MediaPlayer.Ctlcontrols.play();
                timer1.Start();
                volume.Value = 25;
                lbl_volume.Text = volume.Value.ToString() + " %";
                lbl_state.Text = "Playing...";
            }
        }

        private void tn_next_Click(object sender, EventArgs e)
        {
            if (list.SelectedIndex != list.Items.Count - 1)
            {
                list.SelectedIndex = list.SelectedIndex + 1;
                MediaPlayer.URL = path[list.SelectedIndex];
                MediaPlayer.BringToFront();
                MediaPlayer.Ctlcontrols.play();
                timer1.Start();
                volume.Value = 25;
                lbl_volume.Text = volume.Value.ToString() + " %";
                lbl_state.Text = "Playing...";
            }
            else if(list.SelectedIndex == list.Items.Count - 1)
            {
                list.SelectedIndex = 0;
                MediaPlayer.URL = path[list.SelectedIndex];
                MediaPlayer.BringToFront();
                MediaPlayer.Ctlcontrols.play();
                timer1.Start();
                volume.Value = 25;
                lbl_volume.Text = volume.Value.ToString() + " %";
                lbl_state.Text = "Playing...";
            }
        }

        private void volume_Scroll(object sender, EventArgs e)
        {
            MediaPlayer.settings.volume = volume.Value;
            lbl_volume.Text = volume.Value.ToString() + "%";

        }

        private void lbl_starttime_Click(object sender, EventArgs e)
        {

        }

        private void lbl_endtime_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (MediaPlayer.playState == WMPLib.WMPPlayState.wmppsPlaying)
            {
                progress.Maximum = (int)MediaPlayer.Ctlcontrols.currentItem.duration;
                progress.Value = (int)MediaPlayer.Ctlcontrols.currentPosition;
            }
            lbl_starttime.Text = MediaPlayer.Ctlcontrols.currentPositionString;
            lbl_endtime.Text = MediaPlayer.Ctlcontrols.currentItem.durationString.ToString();
        }

        private void progress_Scroll(object sender, EventArgs e)
        {
            MediaPlayer.Ctlcontrols.currentPosition = progress.Value;
        }

        private void Player_Load(object sender, EventArgs e)
        {

        }

        private void btn_skipforward_Click(object sender, EventArgs e)
        {
            MediaPlayer.Ctlcontrols.currentPosition += 10;
        }

        private void btn_skipback_Click(object sender, EventArgs e)
        {
            MediaPlayer.Ctlcontrols.currentPosition -= 10;
        }

        private void Open_Click(object sender, EventArgs e)
        {
                OpenFileDialog open = new OpenFileDialog();
                open.Multiselect = true;
                if (open.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    file_name = open.SafeFileNames;
                    path = open.FileNames;
                    for (int x = 0; x < file_name.Length; x++)
                    {
                        list.Items.Add(file_name[x]);
                    }

                lbl_state.Text = "Files Added...";
                }

            
        }
    }
}
